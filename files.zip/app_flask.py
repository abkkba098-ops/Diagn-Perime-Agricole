"""
API Backend Flask pour la Base de Données des Diagnostics Agricoles de Djibouti

Alternative Python au backend PHP
Nécessite: pip install flask flask-cors pymysql
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
import pymysql
from pymysql.cursors import DictCursor
from datetime import datetime
import json

# Configuration de l'application Flask
app = Flask(__name__)
CORS(app)  # Activer CORS pour toutes les routes

# Configuration de la base de données
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',  # À modifier selon votre configuration
    'database': 'diagnostics_agricoles_djibouti',
    'charset': 'utf8mb4',
    'cursorclass': DictCursor
}

# ========================================
# Utilitaires
# ========================================

def get_db_connection():
    """Créer une connexion à la base de données"""
    try:
        connection = pymysql.connect(**DB_CONFIG)
        return connection
    except Exception as e:
        print(f"Erreur de connexion à la base de données: {e}")
        return None

def format_response(success=True, data=None, error=None, **kwargs):
    """Formater la réponse JSON"""
    response = {
        'success': success,
        'timestamp': datetime.now().isoformat()
    }
    
    if data is not None:
        response['data'] = data
    
    if error is not None:
        response['error'] = error
    
    response.update(kwargs)
    
    return jsonify(response)

# ========================================
# Routes Principales
# ========================================

@app.route('/')
def index():
    """Page d'accueil de l'API"""
    return format_response(
        message="API Diagnostics Agricoles Djibouti",
        version="1.0.0",
        endpoints={
            'regions': '/api/regions',
            'perimetres': '/api/perimetres',
            'parcelles': '/api/parcelles',
            'ouvrages': '/api/ouvrages',
            'statistiques': '/api/statistiques',
            'search': '/api/search'
        }
    )

# ========================================
# RÉGIONS
# ========================================

@app.route('/api/regions', methods=['GET'])
def get_regions():
    """Récupérer toutes les régions avec statistiques"""
    conn = get_db_connection()
    if not conn:
        return format_response(False, error="Erreur de connexion à la base de données"), 500
    
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT r.*,
                       COUNT(DISTINCT p.id) as total_perimetres,
                       COUNT(DISTINCT pa.id) as total_parcelles,
                       COUNT(DISTINCT o.id) as total_ouvrages
                FROM regions r
                LEFT JOIN perimetres p ON p.region_id = r.id
                LEFT JOIN parcelles pa ON pa.perimetre_id = p.id
                LEFT JOIN ouvrages_hydrauliques o ON o.perimetre_id = p.id
                GROUP BY r.id
                ORDER BY r.nom
            """)
            regions = cursor.fetchall()
            
            return format_response(data=regions, count=len(regions))
    
    except Exception as e:
        return format_response(False, error=str(e)), 500
    
    finally:
        conn.close()

@app.route('/api/regions/<int:region_id>', methods=['GET'])
def get_region(region_id):
    """Récupérer une région spécifique"""
    conn = get_db_connection()
    if not conn:
        return format_response(False, error="Erreur de connexion"), 500
    
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT r.*,
                       COUNT(DISTINCT p.id) as total_perimetres,
                       COUNT(DISTINCT pa.id) as total_parcelles,
                       COUNT(DISTINCT o.id) as total_ouvrages
                FROM regions r
                LEFT JOIN perimetres p ON p.region_id = r.id
                LEFT JOIN parcelles pa ON pa.perimetre_id = p.id
                LEFT JOIN ouvrages_hydrauliques o ON o.perimetre_id = p.id
                WHERE r.id = %s
                GROUP BY r.id
            """, (region_id,))
            region = cursor.fetchone()
            
            if region:
                return format_response(data=region)
            else:
                return format_response(False, error="Région non trouvée"), 404
    
    except Exception as e:
        return format_response(False, error=str(e)), 500
    
    finally:
        conn.close()

@app.route('/api/regions', methods=['POST'])
def create_region():
    """Créer une nouvelle région"""
    data = request.get_json()
    
    if not data or 'nom' not in data:
        return format_response(False, error="Le nom de la région est requis"), 400
    
    conn = get_db_connection()
    if not conn:
        return format_response(False, error="Erreur de connexion"), 500
    
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                INSERT INTO regions (nom, description, code_region)
                VALUES (%s, %s, %s)
            """, (
                data['nom'],
                data.get('description'),
                data.get('code_region')
            ))
            conn.commit()
            
            return format_response(
                message="Région créée avec succès",
                id=cursor.lastrowid
            ), 201
    
    except Exception as e:
        conn.rollback()
        return format_response(False, error=str(e)), 500
    
    finally:
        conn.close()

# ========================================
# PÉRIMÈTRES
# ========================================

@app.route('/api/perimetres', methods=['GET'])
def get_perimetres():
    """Récupérer tous les périmètres"""
    region_id = request.args.get('region_id', type=int)
    
    conn = get_db_connection()
    if not conn:
        return format_response(False, error="Erreur de connexion"), 500
    
    try:
        with conn.cursor() as cursor:
            query = """
                SELECT p.*, r.nom as region_nom,
                       COUNT(DISTINCT pa.id) as total_parcelles,
                       COUNT(DISTINCT o.id) as total_ouvrages
                FROM perimetres p
                JOIN regions r ON r.id = p.region_id
                LEFT JOIN parcelles pa ON pa.perimetre_id = p.id
                LEFT JOIN ouvrages_hydrauliques o ON o.perimetre_id = p.id
            """
            
            params = []
            if region_id:
                query += " WHERE p.region_id = %s"
                params.append(region_id)
            
            query += " GROUP BY p.id ORDER BY r.nom, p.nom"
            
            cursor.execute(query, params)
            perimetres = cursor.fetchall()
            
            return format_response(data=perimetres, count=len(perimetres))
    
    except Exception as e:
        return format_response(False, error=str(e)), 500
    
    finally:
        conn.close()

@app.route('/api/perimetres/<int:perimetre_id>', methods=['GET'])
def get_perimetre(perimetre_id):
    """Récupérer un périmètre spécifique"""
    conn = get_db_connection()
    if not conn:
        return format_response(False, error="Erreur de connexion"), 500
    
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT p.*, r.nom as region_nom,
                       COUNT(DISTINCT pa.id) as total_parcelles,
                       COUNT(DISTINCT o.id) as total_ouvrages
                FROM perimetres p
                JOIN regions r ON r.id = p.region_id
                LEFT JOIN parcelles pa ON pa.perimetre_id = p.id
                LEFT JOIN ouvrages_hydrauliques o ON o.perimetre_id = p.id
                WHERE p.id = %s
                GROUP BY p.id
            """, (perimetre_id,))
            perimetre = cursor.fetchone()
            
            if perimetre:
                return format_response(data=perimetre)
            else:
                return format_response(False, error="Périmètre non trouvé"), 404
    
    except Exception as e:
        return format_response(False, error=str(e)), 500
    
    finally:
        conn.close()

@app.route('/api/perimetres', methods=['POST'])
def create_perimetre():
    """Créer un nouveau périmètre"""
    data = request.get_json()
    
    required_fields = ['region_id', 'nom']
    if not all(field in data for field in required_fields):
        return format_response(False, error="Champs requis manquants"), 400
    
    conn = get_db_connection()
    if not conn:
        return format_response(False, error="Erreur de connexion"), 500
    
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                INSERT INTO perimetres (
                    region_id, nom, localite, bassin_versant,
                    coordonnees_gps, superficie_totale, population,
                    nombre_menages, etat_general, description,
                    observations, date_diagnostic
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                data['region_id'],
                data['nom'],
                data.get('localite'),
                data.get('bassin_versant'),
                data.get('coordonnees_gps'),
                data.get('superficie_totale'),
                data.get('population'),
                data.get('nombre_menages'),
                data.get('etat_general', 'non_évalué'),
                data.get('description'),
                data.get('observations'),
                data.get('date_diagnostic')
            ))
            conn.commit()
            
            return format_response(
                message="Périmètre créé avec succès",
                id=cursor.lastrowid
            ), 201
    
    except Exception as e:
        conn.rollback()
        return format_response(False, error=str(e)), 500
    
    finally:
        conn.close()

# ========================================
# PARCELLES
# ========================================

@app.route('/api/parcelles', methods=['GET'])
def get_parcelles():
    """Récupérer les parcelles avec pagination"""
    perimetre_id = request.args.get('perimetre_id', type=int)
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 50, type=int)
    offset = (page - 1) * limit
    
    conn = get_db_connection()
    if not conn:
        return format_response(False, error="Erreur de connexion"), 500
    
    try:
        with conn.cursor() as cursor:
            # Requête principale
            query = """
                SELECT pa.*, p.nom as perimetre_nom, r.nom as region_nom
                FROM parcelles pa
                JOIN perimetres p ON p.id = pa.perimetre_id
                JOIN regions r ON r.id = p.region_id
            """
            
            params = []
            if perimetre_id:
                query += " WHERE pa.perimetre_id = %s"
                params.append(perimetre_id)
            
            query += " ORDER BY r.nom, p.nom, pa.numero_parcelle LIMIT %s OFFSET %s"
            params.extend([limit, offset])
            
            cursor.execute(query, params)
            parcelles = cursor.fetchall()
            
            # Compter le total
            count_query = "SELECT COUNT(*) as total FROM parcelles"
            if perimetre_id:
                count_query += " WHERE perimetre_id = %s"
                cursor.execute(count_query, (perimetre_id,))
            else:
                cursor.execute(count_query)
            
            total = cursor.fetchone()['total']
            
            return format_response(
                data=parcelles,
                pagination={
                    'page': page,
                    'limit': limit,
                    'total': total,
                    'pages': (total + limit - 1) // limit
                }
            )
    
    except Exception as e:
        return format_response(False, error=str(e)), 500
    
    finally:
        conn.close()

# ========================================
# OUVRAGES HYDRAULIQUES
# ========================================

@app.route('/api/ouvrages', methods=['GET'])
def get_ouvrages():
    """Récupérer tous les ouvrages hydrauliques"""
    type_ouvrage = request.args.get('type')
    
    conn = get_db_connection()
    if not conn:
        return format_response(False, error="Erreur de connexion"), 500
    
    try:
        with conn.cursor() as cursor:
            query = """
                SELECT o.*, p.nom as perimetre_nom, r.nom as region_nom
                FROM ouvrages_hydrauliques o
                JOIN perimetres p ON p.id = o.perimetre_id
                JOIN regions r ON r.id = p.region_id
            """
            
            params = []
            if type_ouvrage:
                query += " WHERE o.type_ouvrage = %s"
                params.append(type_ouvrage)
            
            query += " ORDER BY r.nom, p.nom"
            
            cursor.execute(query, params)
            ouvrages = cursor.fetchall()
            
            return format_response(data=ouvrages, count=len(ouvrages))
    
    except Exception as e:
        return format_response(False, error=str(e)), 500
    
    finally:
        conn.close()

# ========================================
# STATISTIQUES
# ========================================

@app.route('/api/statistiques', methods=['GET'])
def get_statistiques():
    """Récupérer les statistiques globales"""
    conn = get_db_connection()
    if not conn:
        return format_response(False, error="Erreur de connexion"), 500
    
    try:
        stats = {}
        
        with conn.cursor() as cursor:
            # Totaux généraux
            cursor.execute("SELECT COUNT(*) as total FROM regions")
            stats['regions'] = cursor.fetchone()['total']
            
            cursor.execute("SELECT COUNT(*) as total FROM perimetres")
            stats['perimetres'] = cursor.fetchone()['total']
            
            cursor.execute("SELECT COUNT(*) as total FROM parcelles")
            stats['parcelles'] = cursor.fetchone()['total']
            
            cursor.execute("SELECT COUNT(*) as total FROM ouvrages_hydrauliques")
            stats['ouvrages'] = cursor.fetchone()['total']
            
            # Répartition par région
            cursor.execute("""
                SELECT r.nom,
                       COUNT(DISTINCT p.id) as perimetres,
                       COUNT(DISTINCT pa.id) as parcelles,
                       COUNT(DISTINCT o.id) as ouvrages
                FROM regions r
                LEFT JOIN perimetres p ON p.region_id = r.id
                LEFT JOIN parcelles pa ON pa.perimetre_id = p.id
                LEFT JOIN ouvrages_hydrauliques o ON o.perimetre_id = p.id
                GROUP BY r.id
                ORDER BY r.nom
            """)
            stats['par_region'] = cursor.fetchall()
            
            # État des périmètres
            cursor.execute("""
                SELECT etat_general, COUNT(*) as nombre
                FROM perimetres
                GROUP BY etat_general
            """)
            stats['etat_perimetres'] = cursor.fetchall()
            
            # État des ouvrages
            cursor.execute("""
                SELECT etat_actuel, COUNT(*) as nombre
                FROM ouvrages_hydrauliques
                GROUP BY etat_actuel
            """)
            stats['etat_ouvrages'] = cursor.fetchall()
        
        return format_response(data=stats)
    
    except Exception as e:
        return format_response(False, error=str(e)), 500
    
    finally:
        conn.close()

# ========================================
# RECHERCHE
# ========================================

@app.route('/api/search', methods=['GET'])
def search():
    """Recherche globale dans la base de données"""
    query = request.args.get('q', '')
    
    if len(query) < 2:
        return format_response(
            False,
            error="La recherche doit contenir au moins 2 caractères"
        ), 400
    
    conn = get_db_connection()
    if not conn:
        return format_response(False, error="Erreur de connexion"), 500
    
    try:
        search_term = f"%{query}%"
        results = {}
        
        with conn.cursor() as cursor:
            # Recherche dans les régions
            cursor.execute(
                "SELECT id, nom, 'region' as type FROM regions WHERE nom LIKE %s LIMIT 5",
                (search_term,)
            )
            results['regions'] = cursor.fetchall()
            
            # Recherche dans les périmètres
            cursor.execute(
                "SELECT id, nom, 'perimetre' as type FROM perimetres WHERE nom LIKE %s OR localite LIKE %s LIMIT 10",
                (search_term, search_term)
            )
            results['perimetres'] = cursor.fetchall()
            
            # Recherche dans les parcelles
            cursor.execute(
                "SELECT id, nom_parcelle as nom, 'parcelle' as type FROM parcelles WHERE nom_parcelle LIKE %s OR nom_exploitant LIKE %s LIMIT 10",
                (search_term, search_term)
            )
            results['parcelles'] = cursor.fetchall()
        
        return format_response(query=query, results=results)
    
    except Exception as e:
        return format_response(False, error=str(e)), 500
    
    finally:
        conn.close()

# ========================================
# Gestion des Erreurs
# ========================================

@app.errorhandler(404)
def not_found(error):
    return format_response(False, error="Endpoint non trouvé"), 404

@app.errorhandler(500)
def internal_error(error):
    return format_response(False, error="Erreur interne du serveur"), 500

# ========================================
# Point d'entrée principal
# ========================================

if __name__ == '__main__':
    print("=" * 80)
    print("API Diagnostics Agricoles Djibouti - Backend Flask")
    print("=" * 80)
    print("\nServeur démarré sur http://localhost:5000")
    print("\nEndpoints disponibles :")
    print("  - GET  /api/regions")
    print("  - GET  /api/regions/<id>")
    print("  - POST /api/regions")
    print("  - GET  /api/perimetres")
    print("  - GET  /api/perimetres/<id>")
    print("  - POST /api/perimetres")
    print("  - GET  /api/parcelles")
    print("  - GET  /api/ouvrages")
    print("  - GET  /api/statistiques")
    print("  - GET  /api/search?q=terme")
    print("\n" + "=" * 80)
    
    # Démarrer le serveur
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=True
    )
