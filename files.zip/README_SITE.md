# 🌾 Site Web Officiel - Diagnostics Agricoles de Djibouti

## 📋 Description

Site web officiel moderne et professionnel pour la gestion et la consultation de la base de données des diagnostics agricoles de la République de Djibouti.

### ✨ Fonctionnalités Principales

- **Interface Moderne** : Design responsive et élégant
- **Navigation Intuitive** : Sections clairement organisées
- **Visualisation de Données** : Tableaux et graphiques interactifs
- **Recherche Avancée** : Filtres et recherche en temps réel
- **Statistiques Détaillées** : Analyses et rapports complets
- **Multi-plateformes** : Compatible desktop, tablette et mobile

---

## 🗂️ Structure du Projet

```
site-web/
│
├── index.html              # Page principale HTML
├── styles.css              # Styles CSS complets
├── app.js                  # JavaScript frontend
├── api.php                 # API Backend PHP (optionnel)
│
├── assets/                 # Ressources (à créer)
│   ├── images/
│   ├── icons/
│   └── documents/
│
└── README.md               # Ce fichier
```

---

## 🚀 Installation Rapide

### Prérequis

- **Serveur Web** : Apache, Nginx, ou serveur PHP intégré
- **PHP** : Version 7.4+ (pour l'API backend)
- **MySQL** : Version 5.7+ ou MariaDB 10.3+
- **Navigateur** : Chrome, Firefox, Safari, Edge (version récente)

### Option 1 : Installation Simple (Frontend uniquement)

Si vous voulez juste visualiser l'interface sans connexion à la base de données :

```bash
# 1. Télécharger les fichiers dans un dossier
cd /chemin/vers/votre/dossier

# 2. Ouvrir index.html dans votre navigateur
# Double-cliquez sur index.html ou utilisez :
open index.html  # macOS
start index.html # Windows
xdg-open index.html # Linux
```

**Note** : En mode frontend seul, les données affichées sont des données de démonstration.

### Option 2 : Installation Complète (avec Backend)

Pour une installation complète avec connexion à MySQL :

#### Étape 1 : Configurer la Base de Données

```bash
# 1. Se connecter à MySQL
mysql -u root -p

# 2. Créer la base de données
source schema_database.sql

# 3. Importer les données
python3 import_data.py
```

#### Étape 2 : Configurer le Backend PHP

```bash
# 1. Éditer api.php et modifier les paramètres de connexion
nano api.php

# Modifier ces lignes :
$config = [
    'host' => 'localhost',
    'database' => 'diagnostics_agricoles_djibouti',
    'username' => 'votre_utilisateur',
    'password' => 'votre_mot_de_passe'
];
```

#### Étape 3 : Démarrer le Serveur

**Option A : Serveur PHP Intégré** (pour développement)

```bash
php -S localhost:8000
```

Puis ouvrez : `http://localhost:8000`

**Option B : Apache/Nginx** (pour production)

```bash
# Copier les fichiers dans le répertoire web
sudo cp -r * /var/www/html/diagnostics-agricoles/

# Configurer Apache Virtual Host (exemple)
sudo nano /etc/apache2/sites-available/diagnostics.conf
```

Contenu du fichier de configuration Apache :

```apache
<VirtualHost *:80>
    ServerName diagnostics-agricoles.dj
    DocumentRoot /var/www/html/diagnostics-agricoles
    
    <Directory /var/www/html/diagnostics-agricoles>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    
    ErrorLog ${APACHE_LOG_DIR}/diagnostics_error.log
    CustomLog ${APACHE_LOG_DIR}/diagnostics_access.log combined
</VirtualHost>
```

```bash
# Activer le site
sudo a2ensite diagnostics.conf
sudo systemctl reload apache2
```

---

## 🎨 Sections du Site

### 1. **Accueil** 🏠
- Vue d'ensemble avec statistiques clés
- Cartes statistiques animées
- Accès rapide aux sections principales
- Design hero moderne

### 2. **Régions** 🗺️
- Liste de toutes les régions de Djibouti
- Statistiques par région
- Cartes interactives cliquables
- Détails complets de chaque région

### 3. **Périmètres** 🌱
- Périmètres agricoles par région
- Filtrage par région
- État général de chaque périmètre
- Informations détaillées (superficie, population, GPS)

### 4. **Parcelles** 📊
- Tableau complet des parcelles
- Filtrage et recherche avancée
- Informations sur les exploitants
- État d'exploitation

### 5. **Ouvrages Hydrauliques** 🔧
- Liste des ouvrages (forages, puits, barrages)
- État actuel et travaux nécessaires
- Coordonnées GPS
- Filtrage par type

### 6. **Statistiques** 📈
- Graphiques interactifs (Chart.js)
- Répartition par région
- État des ouvrages
- Analyses des cultures

### 7. **Documentation** 📚
- Guide d'installation
- Structure de la base de données
- Documentation API
- Téléchargement des fichiers système

---

## 🔧 Configuration Avancée

### Personnalisation des Couleurs

Éditez `styles.css` et modifiez les variables CSS :

```css
:root {
    --primary-color: #27ae60;      /* Couleur principale */
    --secondary-color: #2c3e50;    /* Couleur secondaire */
    --accent-color: #3498db;       /* Couleur d'accent */
    /* ... autres couleurs ... */
}
```

### Modification du Logo

Remplacez le SVG dans `index.html` :

```html
<img src="votre-logo.png" alt="Logo" class="nav-logo">
```

### Ajout de Nouvelles Sections

1. Ajouter dans la navigation :
```html
<li><a href="#nouvelle-section" onclick="showSection('nouvelle-section')">
    <i class="fas fa-icon"></i> Nouvelle Section
</a></li>
```

2. Créer la section :
```html
<section id="nouvelle-section" class="section">
    <div class="container">
        <!-- Contenu de la section -->
    </div>
</section>
```

3. Ajouter la fonction JavaScript :
```javascript
case 'nouvelle-section':
    loadNouvelleSection();
    break;
```

---

## 🔌 API Backend

### Endpoints Disponibles

#### Régions
```
GET    /api.php?action=regions           # Liste toutes les régions
GET    /api.php?action=regions&id=1      # Détails d'une région
POST   /api.php?action=regions           # Créer une région
PUT    /api.php?action=regions&id=1      # Modifier une région
DELETE /api.php?action=regions&id=1      # Supprimer une région
```

#### Périmètres
```
GET    /api.php?action=perimetres                    # Liste tous les périmètres
GET    /api.php?action=perimetres&region_id=1        # Périmètres d'une région
GET    /api.php?action=perimetres&id=1               # Détails d'un périmètre
POST   /api.php?action=perimetres                    # Créer un périmètre
```

#### Parcelles
```
GET    /api.php?action=parcelles&page=1&limit=50     # Liste paginée
GET    /api.php?action=parcelles&perimetre_id=1      # Parcelles d'un périmètre
```

#### Ouvrages
```
GET    /api.php?action=ouvrages                      # Liste tous les ouvrages
GET    /api.php?action=ouvrages&type=forage          # Filtrer par type
```

#### Statistiques
```
GET    /api.php?action=statistiques                  # Statistiques globales
```

#### Recherche
```
GET    /api.php?action=search&q=terme                # Recherche globale
```

### Exemple d'Utilisation avec JavaScript

```javascript
// Récupérer toutes les régions
fetch('api.php?action=regions')
    .then(response => response.json())
    .then(data => {
        console.log(data);
        // Traiter les données
    });

// Ajouter une nouvelle région
fetch('api.php?action=regions', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json'
    },
    body: JSON.stringify({
        nom: 'Nouvelle Région',
        code_region: 'NR',
        description: 'Description...'
    })
})
    .then(response => response.json())
    .then(data => console.log(data));
```

---

## 📱 Responsive Design

Le site est entièrement responsive et s'adapte à toutes les tailles d'écran :

- **Desktop** : Affichage complet avec toutes les fonctionnalités
- **Tablette** : Layout optimisé avec grilles adaptatives
- **Mobile** : Menu hamburger, navigation simplifiée

### Points de Rupture (Breakpoints)

```css
/* Tablette */
@media (max-width: 768px) { ... }

/* Mobile */
@media (max-width: 480px) { ... }
```

---

## 🔒 Sécurité

### Recommandations de Production

1. **Authentification** : Ajouter un système de login
2. **HTTPS** : Utiliser un certificat SSL
3. **Validation** : Valider toutes les entrées utilisateur
4. **SQL Injection** : Utiliser des requêtes préparées (déjà implémenté)
5. **CORS** : Restreindre les origines autorisées
6. **Sessions** : Implémenter la gestion des sessions

### Exemple de Configuration Apache Sécurisée

```apache
<VirtualHost *:443>
    ServerName diagnostics-agricoles.dj
    
    SSLEngine on
    SSLCertificateFile /path/to/cert.pem
    SSLCertificateKeyFile /path/to/key.pem
    
    # Sécurité supplémentaire
    Header always set X-Frame-Options "SAMEORIGIN"
    Header always set X-Content-Type-Options "nosniff"
    Header always set X-XSS-Protection "1; mode=block"
    
    # ... reste de la configuration ...
</VirtualHost>
```

---

## 🐛 Dépannage

### Problème : Page blanche
**Solution** : Vérifier la console JavaScript (F12) pour les erreurs

### Problème : Données non chargées
**Solution** : 
1. Vérifier que MySQL est démarré
2. Vérifier les paramètres de connexion dans `api.php`
3. Vérifier les logs PHP : `tail -f /var/log/apache2/error.log`

### Problème : CORS Error
**Solution** : Vérifier les headers CORS dans `api.php`

### Problème : Graphiques non affichés
**Solution** : Vérifier que Chart.js est chargé :
```html
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
```

---

## 📊 Performance

### Optimisations Recommandées

1. **Minification** : Minifier CSS et JS pour la production
```bash
# Exemple avec UglifyJS
uglifyjs app.js -o app.min.js -c -m
```

2. **Compression** : Activer la compression Gzip
```apache
# Dans .htaccess
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/css text/javascript
</IfModule>
```

3. **Cache** : Mettre en cache les ressources statiques
```apache
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType text/css "access plus 1 month"
    ExpiresByType application/javascript "access plus 1 month"
</IfModule>
```

4. **CDN** : Utiliser un CDN pour Chart.js et Font Awesome

---

## 🔄 Mises à Jour

### Version 1.0.0 (Actuelle)
- Interface complète avec 7 sections
- API REST complète
- Design responsive
- Graphiques interactifs
- Documentation complète

### Roadmap Futures Versions

- [ ] **v1.1.0** : Système d'authentification
- [ ] **v1.2.0** : Export PDF/Excel des rapports
- [ ] **v1.3.0** : Cartes interactives avec Leaflet.js
- [ ] **v1.4.0** : Application mobile (React Native)
- [ ] **v2.0.0** : Dashboard temps réel avec WebSockets

---

## 🤝 Contribution

Pour contribuer au projet :

1. Fork le projet
2. Créer une branche (`git checkout -b feature/nouvelle-fonctionnalite`)
3. Commit les changements (`git commit -m 'Ajout nouvelle fonctionnalité'`)
4. Push vers la branche (`git push origin feature/nouvelle-fonctionnalite`)
5. Ouvrir une Pull Request

---

## 📞 Support

Pour toute question ou problème :

- **Email** : support@agriculture.dj
- **Téléphone** : +253 XX XX XX XX
- **Documentation** : Voir section Documentation du site

---

## 📄 Licence

Ce projet est destiné à l'usage interne du **Ministère de l'Agriculture de la République de Djibouti**.

---

## 👥 Crédits

- **Design & Développement** : Équipe Technique Ministère de l'Agriculture
- **Données** : Diagnostics des périmètres agricoles 2026
- **Technologies** : HTML5, CSS3, JavaScript, PHP, MySQL, Chart.js

---

## 🇩🇯 République de Djibouti

**Ministère de l'Agriculture, de l'Eau, de la Pêche, de l'Élevage et des Ressources Halieutiques**

*Développé avec 💚 pour l'agriculture djiboutienne*

---

**Dernière mise à jour** : Février 2026  
**Version** : 1.0.0
