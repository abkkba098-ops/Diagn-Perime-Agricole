<?php
/**
 * API REST pour la Base de Données des Diagnostics Agricoles de Djibouti
 * 
 * Ce fichier gère toutes les requêtes API entre le frontend et MySQL
 */

// Configuration CORS
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Gestion des requêtes OPTIONS (preflight)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Configuration de la base de données
$config = [
    'host' => 'localhost',
    'database' => 'diagnostics_agricoles_djibouti',
    'username' => 'root',
    'password' => '', // À modifier selon votre configuration
    'charset' => 'utf8mb4'
];

// Connexion à la base de données
try {
    $dsn = "mysql:host={$config['host']};dbname={$config['database']};charset={$config['charset']}";
    $pdo = new PDO($dsn, $config['username'], $config['password']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Erreur de connexion à la base de données',
        'message' => $e->getMessage()
    ]);
    exit();
}

// Récupération de l'action demandée
$action = $_GET['action'] ?? 'error';
$method = $_SERVER['REQUEST_METHOD'];

// Routeur principal
try {
    switch ($action) {
        case 'regions':
            handleRegions($pdo, $method);
            break;
        
        case 'perimetres':
            handlePerimetres($pdo, $method);
            break;
        
        case 'parcelles':
            handleParcelles($pdo, $method);
            break;
        
        case 'ouvrages':
            handleOuvrages($pdo, $method);
            break;
        
        case 'statistiques':
            handleStatistiques($pdo);
            break;
        
        case 'search':
            handleSearch($pdo);
            break;
        
        default:
            http_response_code(404);
            echo json_encode([
                'success' => false,
                'error' => 'Action non trouvée'
            ]);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Erreur serveur',
        'message' => $e->getMessage()
    ]);
}

// ========================================
// GESTION DES RÉGIONS
// ========================================
function handleRegions($pdo, $method) {
    switch ($method) {
        case 'GET':
            $id = $_GET['id'] ?? null;
            
            if ($id) {
                // Récupérer une région spécifique
                $stmt = $pdo->prepare("
                    SELECT r.*,
                           COUNT(DISTINCT p.id) as total_perimetres,
                           COUNT(DISTINCT pa.id) as total_parcelles,
                           COUNT(DISTINCT o.id) as total_ouvrages
                    FROM regions r
                    LEFT JOIN perimetres p ON p.region_id = r.id
                    LEFT JOIN parcelles pa ON pa.perimetre_id = p.id
                    LEFT JOIN ouvrages_hydrauliques o ON o.perimetre_id = p.id
                    WHERE r.id = ?
                    GROUP BY r.id
                ");
                $stmt->execute([$id]);
                $region = $stmt->fetch();
                
                echo json_encode([
                    'success' => true,
                    'data' => $region
                ]);
            } else {
                // Récupérer toutes les régions avec statistiques
                $stmt = $pdo->query("
                    SELECT r.*,
                           COUNT(DISTINCT p.id) as total_perimetres,
                           COUNT(DISTINCT pa.id) as total_parcelles,
                           COUNT(DISTINCT o.id) as total_ouvrages
                    FROM regions r
                    LEFT JOIN perimetres p ON p.region_id = r.id
                    LEFT JOIN parcelles pa ON pa.perimetre_id = p.id
                    LEFT JOIN ouvrages_hydrauliques o ON o.perimetre_id = p.id
                    GROUP BY r.id
                    ORDER BY r.nom
                ");
                $regions = $stmt->fetchAll();
                
                echo json_encode([
                    'success' => true,
                    'data' => $regions,
                    'count' => count($regions)
                ]);
            }
            break;
        
        case 'POST':
            $data = json_decode(file_get_contents('php://input'), true);
            
            $stmt = $pdo->prepare("
                INSERT INTO regions (nom, description, code_region)
                VALUES (?, ?, ?)
            ");
            $stmt->execute([
                $data['nom'],
                $data['description'] ?? null,
                $data['code_region'] ?? null
            ]);
            
            echo json_encode([
                'success' => true,
                'message' => 'Région ajoutée avec succès',
                'id' => $pdo->lastInsertId()
            ]);
            break;
        
        case 'PUT':
            $id = $_GET['id'] ?? null;
            if (!$id) {
                throw new Exception('ID requis pour la modification');
            }
            
            $data = json_decode(file_get_contents('php://input'), true);
            
            $stmt = $pdo->prepare("
                UPDATE regions
                SET nom = ?, description = ?, code_region = ?
                WHERE id = ?
            ");
            $stmt->execute([
                $data['nom'],
                $data['description'] ?? null,
                $data['code_region'] ?? null,
                $id
            ]);
            
            echo json_encode([
                'success' => true,
                'message' => 'Région modifiée avec succès'
            ]);
            break;
        
        case 'DELETE':
            $id = $_GET['id'] ?? null;
            if (!$id) {
                throw new Exception('ID requis pour la suppression');
            }
            
            $stmt = $pdo->prepare("DELETE FROM regions WHERE id = ?");
            $stmt->execute([$id]);
            
            echo json_encode([
                'success' => true,
                'message' => 'Région supprimée avec succès'
            ]);
            break;
    }
}

// ========================================
// GESTION DES PÉRIMÈTRES
// ========================================
function handlePerimetres($pdo, $method) {
    switch ($method) {
        case 'GET':
            $id = $_GET['id'] ?? null;
            $region_id = $_GET['region_id'] ?? null;
            
            if ($id) {
                // Récupérer un périmètre spécifique
                $stmt = $pdo->prepare("
                    SELECT p.*, r.nom as region_nom,
                           COUNT(DISTINCT pa.id) as total_parcelles,
                           COUNT(DISTINCT o.id) as total_ouvrages
                    FROM perimetres p
                    JOIN regions r ON r.id = p.region_id
                    LEFT JOIN parcelles pa ON pa.perimetre_id = p.id
                    LEFT JOIN ouvrages_hydrauliques o ON o.perimetre_id = p.id
                    WHERE p.id = ?
                    GROUP BY p.id
                ");
                $stmt->execute([$id]);
                $perimetre = $stmt->fetch();
                
                echo json_encode([
                    'success' => true,
                    'data' => $perimetre
                ]);
            } else {
                // Récupérer tous les périmètres
                $sql = "
                    SELECT p.*, r.nom as region_nom,
                           COUNT(DISTINCT pa.id) as total_parcelles,
                           COUNT(DISTINCT o.id) as total_ouvrages
                    FROM perimetres p
                    JOIN regions r ON r.id = p.region_id
                    LEFT JOIN parcelles pa ON pa.perimetre_id = p.id
                    LEFT JOIN ouvrages_hydrauliques o ON o.perimetre_id = p.id
                ";
                
                if ($region_id) {
                    $sql .= " WHERE p.region_id = ?";
                }
                
                $sql .= " GROUP BY p.id ORDER BY r.nom, p.nom";
                
                $stmt = $pdo->prepare($sql);
                if ($region_id) {
                    $stmt->execute([$region_id]);
                } else {
                    $stmt->execute();
                }
                
                $perimetres = $stmt->fetchAll();
                
                echo json_encode([
                    'success' => true,
                    'data' => $perimetres,
                    'count' => count($perimetres)
                ]);
            }
            break;
        
        case 'POST':
            $data = json_decode(file_get_contents('php://input'), true);
            
            $stmt = $pdo->prepare("
                INSERT INTO perimetres (
                    region_id, nom, localite, bassin_versant,
                    coordonnees_gps, superficie_totale, population,
                    nombre_menages, etat_general, description,
                    observations, date_diagnostic
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $data['region_id'],
                $data['nom'],
                $data['localite'] ?? null,
                $data['bassin_versant'] ?? null,
                $data['coordonnees_gps'] ?? null,
                $data['superficie_totale'] ?? null,
                $data['population'] ?? null,
                $data['nombre_menages'] ?? null,
                $data['etat_general'] ?? 'non_évalué',
                $data['description'] ?? null,
                $data['observations'] ?? null,
                $data['date_diagnostic'] ?? null
            ]);
            
            echo json_encode([
                'success' => true,
                'message' => 'Périmètre ajouté avec succès',
                'id' => $pdo->lastInsertId()
            ]);
            break;
    }
}

// ========================================
// GESTION DES PARCELLES
// ========================================
function handleParcelles($pdo, $method) {
    switch ($method) {
        case 'GET':
            $perimetre_id = $_GET['perimetre_id'] ?? null;
            $page = $_GET['page'] ?? 1;
            $limit = $_GET['limit'] ?? 50;
            $offset = ($page - 1) * $limit;
            
            $sql = "
                SELECT pa.*, p.nom as perimetre_nom, r.nom as region_nom
                FROM parcelles pa
                JOIN perimetres p ON p.id = pa.perimetre_id
                JOIN regions r ON r.id = p.region_id
            ";
            
            if ($perimetre_id) {
                $sql .= " WHERE pa.perimetre_id = ?";
            }
            
            $sql .= " ORDER BY r.nom, p.nom, pa.numero_parcelle";
            $sql .= " LIMIT ? OFFSET ?";
            
            $stmt = $pdo->prepare($sql);
            if ($perimetre_id) {
                $stmt->execute([$perimetre_id, $limit, $offset]);
            } else {
                $stmt->execute([$limit, $offset]);
            }
            
            $parcelles = $stmt->fetchAll();
            
            // Compter le total
            $countSql = "SELECT COUNT(*) as total FROM parcelles";
            if ($perimetre_id) {
                $countSql .= " WHERE perimetre_id = ?";
                $countStmt = $pdo->prepare($countSql);
                $countStmt->execute([$perimetre_id]);
            } else {
                $countStmt = $pdo->query($countSql);
            }
            $total = $countStmt->fetch()['total'];
            
            echo json_encode([
                'success' => true,
                'data' => $parcelles,
                'pagination' => [
                    'page' => (int)$page,
                    'limit' => (int)$limit,
                    'total' => (int)$total,
                    'pages' => ceil($total / $limit)
                ]
            ]);
            break;
    }
}

// ========================================
// GESTION DES OUVRAGES
// ========================================
function handleOuvrages($pdo, $method) {
    switch ($method) {
        case 'GET':
            $type = $_GET['type'] ?? null;
            
            $sql = "
                SELECT o.*, p.nom as perimetre_nom, r.nom as region_nom
                FROM ouvrages_hydrauliques o
                JOIN perimetres p ON p.id = o.perimetre_id
                JOIN regions r ON r.id = p.region_id
            ";
            
            if ($type) {
                $sql .= " WHERE o.type_ouvrage = ?";
            }
            
            $sql .= " ORDER BY r.nom, p.nom";
            
            $stmt = $pdo->prepare($sql);
            if ($type) {
                $stmt->execute([$type]);
            } else {
                $stmt->execute();
            }
            
            $ouvrages = $stmt->fetchAll();
            
            echo json_encode([
                'success' => true,
                'data' => $ouvrages,
                'count' => count($ouvrages)
            ]);
            break;
    }
}

// ========================================
// STATISTIQUES GLOBALES
// ========================================
function handleStatistiques($pdo) {
    // Statistiques générales
    $stats = [];
    
    // Total par type
    $queries = [
        'regions' => "SELECT COUNT(*) as total FROM regions",
        'perimetres' => "SELECT COUNT(*) as total FROM perimetres",
        'parcelles' => "SELECT COUNT(*) as total FROM parcelles",
        'ouvrages' => "SELECT COUNT(*) as total FROM ouvrages_hydrauliques"
    ];
    
    foreach ($queries as $key => $query) {
        $result = $pdo->query($query)->fetch();
        $stats[$key] = (int)$result['total'];
    }
    
    // Répartition par région
    $stmt = $pdo->query("
        SELECT r.nom,
               COUNT(DISTINCT p.id) as perimetres,
               COUNT(DISTINCT pa.id) as parcelles,
               COUNT(DISTINCT o.id) as ouvrages
        FROM regions r
        LEFT JOIN perimetres p ON p.region_id = r.id
        LEFT JOIN parcelles pa ON pa.perimetre_id = p.id
        LEFT JOIN ouvrages_hydrauliques o ON o.perimetre_id = p.id
        GROUP BY r.id
        ORDER BY r.nom
    ");
    $stats['par_region'] = $stmt->fetchAll();
    
    // État des périmètres
    $stmt = $pdo->query("
        SELECT etat_general, COUNT(*) as nombre
        FROM perimetres
        GROUP BY etat_general
    ");
    $stats['etat_perimetres'] = $stmt->fetchAll();
    
    // État des ouvrages
    $stmt = $pdo->query("
        SELECT etat_actuel, COUNT(*) as nombre
        FROM ouvrages_hydrauliques
        GROUP BY etat_actuel
    ");
    $stats['etat_ouvrages'] = $stmt->fetchAll();
    
    echo json_encode([
        'success' => true,
        'data' => $stats
    ]);
}

// ========================================
// RECHERCHE GLOBALE
// ========================================
function handleSearch($pdo) {
    $query = $_GET['q'] ?? '';
    
    if (strlen($query) < 2) {
        echo json_encode([
            'success' => false,
            'error' => 'La recherche doit contenir au moins 2 caractères'
        ]);
        return;
    }
    
    $searchTerm = "%{$query}%";
    $results = [];
    
    // Recherche dans les régions
    $stmt = $pdo->prepare("SELECT id, nom, 'region' as type FROM regions WHERE nom LIKE ? LIMIT 5");
    $stmt->execute([$searchTerm]);
    $results['regions'] = $stmt->fetchAll();
    
    // Recherche dans les périmètres
    $stmt = $pdo->prepare("SELECT id, nom, 'perimetre' as type FROM perimetres WHERE nom LIKE ? OR localite LIKE ? LIMIT 10");
    $stmt->execute([$searchTerm, $searchTerm]);
    $results['perimetres'] = $stmt->fetchAll();
    
    // Recherche dans les parcelles
    $stmt = $pdo->prepare("SELECT id, nom_parcelle as nom, 'parcelle' as type FROM parcelles WHERE nom_parcelle LIKE ? OR nom_exploitant LIKE ? LIMIT 10");
    $stmt->execute([$searchTerm, $searchTerm]);
    $results['parcelles'] = $stmt->fetchAll();
    
    echo json_encode([
        'success' => true,
        'query' => $query,
        'results' => $results
    ]);
}
