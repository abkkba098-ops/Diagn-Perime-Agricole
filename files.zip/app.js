// ================================
// Configuration et Données Mock
// ================================

const API_BASE_URL = 'api.php'; // À configurer selon votre backend

// Données simulées (à remplacer par des appels API)
const mockData = {
    regions: [
        {
            id: 1, 
            nom: 'Tadjourah', 
            code_region: 'TAD',
            perimetres: 9, 
            parcelles: 141, 
            ouvrages: 16,
            description: 'Région côtière du nord'
        },
        {
            id: 2, 
            nom: 'Dikhil', 
            code_region: 'DIK',
            perimetres: 9, 
            parcelles: 803, 
            ouvrages: 0,
            description: 'Région agricole centrale'
        },
        {
            id: 3, 
            nom: 'Ali Sabieh', 
            code_region: 'ALI',
            perimetres: 7, 
            parcelles: 0, 
            ouvrages: 0,
            description: 'Région frontalière sud'
        },
        {
            id: 4, 
            nom: 'Arta', 
            code_region: 'ART',
            perimetres: 4, 
            parcelles: 0, 
            ouvrages: 0,
            description: 'Région du sud-est'
        },
        {
            id: 5, 
            nom: 'Obock', 
            code_region: 'OBO',
            perimetres: 2, 
            parcelles: 0, 
            ouvrages: 0,
            description: 'Région du nord'
        },
        {
            id: 6, 
            nom: 'Djibouti', 
            code_region: 'DJI',
            perimetres: 1, 
            parcelles: 72, 
            ouvrages: 0,
            description: 'Région de la capitale'
        }
    ],
    perimetres: [
        {
            id: 1,
            region_id: 1,
            nom: 'Périmètre Dorra',
            localite: 'Dorra',
            superficie_totale: 45.5,
            population: 250,
            nombre_menages: 45,
            etat_general: 'bon',
            coordonnees_gps: '11.7742, 42.8511'
        },
        {
            id: 2,
            region_id: 1,
            nom: 'Périmètre Ambado',
            localite: 'Ambado',
            superficie_totale: 38.2,
            population: 180,
            nombre_menages: 32,
            etat_general: 'moyen',
            coordonnees_gps: '11.8123, 42.9045'
        },
        {
            id: 3,
            region_id: 2,
            nom: 'Périmètre Hanlé',
            localite: 'Hanlé',
            superficie_totale: 120.0,
            population: 500,
            nombre_menages: 95,
            etat_general: 'bon',
            coordonnees_gps: '11.5234, 42.3678'
        }
    ],
    parcelles: [],
    ouvrages: []
};

// ================================
// Utilitaires
// ================================

function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function showToast(message, type = 'success') {
    const toast = document.getElementById('toast');
    const toastMessage = document.getElementById('toast-message');
    
    toast.className = `toast show ${type}`;
    toastMessage.textContent = message;
    
    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

function toggleMobileMenu() {
    const navMenu = document.getElementById('navMenu');
    navMenu.classList.toggle('active');
}

// ================================
// Navigation entre Sections
// ================================

function showSection(sectionId) {
    // Masquer toutes les sections
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Afficher la section demandée
    const section = document.getElementById(sectionId);
    if (section) {
        section.classList.add('active');
        
        // Fermer le menu mobile
        const navMenu = document.getElementById('navMenu');
        navMenu.classList.remove('active');
        
        // Scroller vers le haut
        window.scrollTo({ top: 0, behavior: 'smooth' });
        
        // Charger les données de la section
        loadSectionData(sectionId);
    }
}

function loadSectionData(sectionId) {
    switch(sectionId) {
        case 'regions':
            loadRegions();
            break;
        case 'perimetres':
            loadPerimetres();
            loadRegionFilters();
            break;
        case 'parcelles':
            loadParcelles();
            loadPerimetreFilters();
            break;
        case 'ouvrages':
            loadOuvrages();
            break;
        case 'statistiques':
            loadStatistics();
            break;
    }
}

// ================================
// Chargement des Régions
// ================================

function loadRegions() {
    const container = document.getElementById('regions-grid');
    if (!container) return;
    
    let html = '';
    
    mockData.regions.forEach(region => {
        html += `
            <div class="region-card" onclick="showRegionDetails(${region.id})">
                <h3>
                    <i class="fas fa-map-marker-alt"></i>
                    ${region.nom}
                </h3>
                <p style="color: var(--text-light); margin-bottom: 1rem;">${region.description || ''}</p>
                <div class="region-info">
                    <div class="info-item">
                        <span class="info-value">${region.perimetres}</span>
                        <span class="info-label">Périmètres</span>
                    </div>
                    <div class="info-item">
                        <span class="info-value">${formatNumber(region.parcelles)}</span>
                        <span class="info-label">Parcelles</span>
                    </div>
                    <div class="info-item">
                        <span class="info-value">${region.ouvrages}</span>
                        <span class="info-label">Ouvrages</span>
                    </div>
                    <div class="info-item">
                        <span class="info-value">${region.code_region}</span>
                        <span class="info-label">Code</span>
                    </div>
                </div>
                <button class="btn btn-primary mt-3" style="width: 100%;" onclick="event.stopPropagation(); filterByRegion(${region.id})">
                    <i class="fas fa-eye"></i> Voir les Détails
                </button>
            </div>
        `;
    });
    
    container.innerHTML = html;
}

function showRegionDetails(regionId) {
    const region = mockData.regions.find(r => r.id === regionId);
    if (!region) return;
    
    const modal = document.getElementById('detail-modal');
    const title = document.getElementById('detail-modal-title');
    const body = document.getElementById('detail-modal-body');
    
    title.innerHTML = `<i class="fas fa-map-marked-alt"></i> Région de ${region.nom}`;
    
    body.innerHTML = `
        <div style="display: grid; gap: 1.5rem;">
            <div>
                <h4 style="color: var(--primary-color); margin-bottom: 0.5rem;">
                    <i class="fas fa-info-circle"></i> Informations Générales
                </h4>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; background: var(--bg-light); padding: 1rem; border-radius: var(--border-radius);">
                    <div>
                        <strong>Code Région:</strong><br>${region.code_region}
                    </div>
                    <div>
                        <strong>Nom:</strong><br>${region.nom}
                    </div>
                    <div>
                        <strong>Description:</strong><br>${region.description || 'N/A'}
                    </div>
                </div>
            </div>
            
            <div>
                <h4 style="color: var(--primary-color); margin-bottom: 0.5rem;">
                    <i class="fas fa-chart-bar"></i> Statistiques
                </h4>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem;">
                    <div style="background: var(--bg-light); padding: 1rem; border-radius: var(--border-radius); text-align: center;">
                        <div style="font-size: 2rem; font-weight: bold; color: var(--primary-color);">${region.perimetres}</div>
                        <div style="color: var(--text-light);">Périmètres</div>
                    </div>
                    <div style="background: var(--bg-light); padding: 1rem; border-radius: var(--border-radius); text-align: center;">
                        <div style="font-size: 2rem; font-weight: bold; color: var(--accent-color);">${formatNumber(region.parcelles)}</div>
                        <div style="color: var(--text-light);">Parcelles</div>
                    </div>
                    <div style="background: var(--bg-light); padding: 1rem; border-radius: var(--border-radius); text-align: center;">
                        <div style="font-size: 2rem; font-weight: bold; color: var(--warning-color);">${region.ouvrages}</div>
                        <div style="color: var(--text-light);">Ouvrages</div>
                    </div>
                </div>
            </div>
            
            <div>
                <button class="btn btn-primary" onclick="filterByRegion(${region.id}); closeDetailModal();">
                    <i class="fas fa-seedling"></i> Voir les Périmètres
                </button>
                <button class="btn btn-secondary" onclick="closeDetailModal()">
                    <i class="fas fa-times"></i> Fermer
                </button>
            </div>
        </div>
    `;
    
    modal.classList.add('active');
}

function filterByRegion(regionId) {
    showSection('perimetres');
    setTimeout(() => {
        const filter = document.getElementById('filter-region-perimetres');
        if (filter) {
            filter.value = regionId;
            loadPerimetres();
        }
    }, 100);
}

function filterRegions(searchText) {
    const cards = document.querySelectorAll('.region-card');
    searchText = searchText.toLowerCase();
    
    cards.forEach(card => {
        const text = card.textContent.toLowerCase();
        card.style.display = text.includes(searchText) ? 'block' : 'none';
    });
}

// ================================
// Chargement des Périmètres
// ================================

function loadRegionFilters() {
    const filter = document.getElementById('filter-region-perimetres');
    if (!filter) return;
    
    let html = '<option value="">Toutes les régions</option>';
    mockData.regions.forEach(region => {
        html += `<option value="${region.id}">${region.nom}</option>`;
    });
    filter.innerHTML = html;
}

function loadPerimetres() {
    const container = document.getElementById('perimetres-container');
    if (!container) return;
    
    const regionFilter = document.getElementById('filter-region-perimetres');
    const selectedRegion = regionFilter ? parseInt(regionFilter.value) : null;
    
    let perimetres = mockData.perimetres;
    if (selectedRegion) {
        perimetres = perimetres.filter(p => p.region_id === selectedRegion);
    }
    
    if (perimetres.length === 0) {
        container.innerHTML = `
            <div style="text-align: center; padding: 3rem; background: white; border-radius: var(--border-radius-lg);">
                <i class="fas fa-info-circle" style="font-size: 3rem; color: var(--text-light); margin-bottom: 1rem;"></i>
                <p style="color: var(--text-light); font-size: 1.1rem;">Aucun périmètre trouvé</p>
            </div>
        `;
        return;
    }
    
    let html = '';
    perimetres.forEach(perimetre => {
        const region = mockData.regions.find(r => r.id === perimetre.region_id);
        const badgeClass = `badge-${perimetre.etat_general}`;
        
        html += `
            <div class="perimetre-card" onclick="showPerimetreDetails(${perimetre.id})">
                <div class="perimetre-header">
                    <div class="perimetre-title">
                        <i class="fas fa-seedling"></i> ${perimetre.nom}
                    </div>
                    <span class="badge ${badgeClass}">${perimetre.etat_general}</span>
                </div>
                <div class="perimetre-details">
                    <div class="detail-item">
                        <span class="detail-label">Région</span>
                        <span class="detail-value">${region ? region.nom : 'N/A'}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Localité</span>
                        <span class="detail-value">${perimetre.localite || 'N/A'}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Superficie</span>
                        <span class="detail-value">${perimetre.superficie_totale} ha</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Population</span>
                        <span class="detail-value">${perimetre.population || 0}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Ménages</span>
                        <span class="detail-value">${perimetre.nombre_menages || 0}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">GPS</span>
                        <span class="detail-value" style="font-size: 0.9rem;">${perimetre.coordonnees_gps || 'N/A'}</span>
                    </div>
                </div>
            </div>
        `;
    });
    
    container.innerHTML = html;
}

function showPerimetreDetails(perimetreId) {
    const perimetre = mockData.perimetres.find(p => p.id === perimetreId);
    if (!perimetre) return;
    
    const region = mockData.regions.find(r => r.id === perimetre.region_id);
    const modal = document.getElementById('detail-modal');
    const title = document.getElementById('detail-modal-title');
    const body = document.getElementById('detail-modal-body');
    
    title.innerHTML = `<i class="fas fa-seedling"></i> ${perimetre.nom}`;
    
    const badgeClass = `badge-${perimetre.etat_general}`;
    
    body.innerHTML = `
        <div style="display: grid; gap: 1.5rem;">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <h4 style="color: var(--primary-color);">
                    <i class="fas fa-info-circle"></i> Informations Générales
                </h4>
                <span class="badge ${badgeClass}">${perimetre.etat_general}</span>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
                <div style="background: var(--bg-light); padding: 1rem; border-radius: var(--border-radius);">
                    <strong>Région:</strong><br>${region ? region.nom : 'N/A'}
                </div>
                <div style="background: var(--bg-light); padding: 1rem; border-radius: var(--border-radius);">
                    <strong>Localité:</strong><br>${perimetre.localite || 'N/A'}
                </div>
                <div style="background: var(--bg-light); padding: 1rem; border-radius: var(--border-radius);">
                    <strong>Superficie:</strong><br>${perimetre.superficie_totale} ha
                </div>
                <div style="background: var(--bg-light); padding: 1rem; border-radius: var(--border-radius);">
                    <strong>Population:</strong><br>${perimetre.population || 0}
                </div>
                <div style="background: var(--bg-light); padding: 1rem; border-radius: var(--border-radius);">
                    <strong>Ménages:</strong><br>${perimetre.nombre_menages || 0}
                </div>
                <div style="background: var(--bg-light); padding: 1rem; border-radius: var(--border-radius);">
                    <strong>GPS:</strong><br><small>${perimetre.coordonnees_gps || 'N/A'}</small>
                </div>
            </div>
            
            ${perimetre.coordonnees_gps ? `
                <div>
                    <button class="btn btn-accent" onclick="window.open('https://www.google.com/maps?q=${perimetre.coordonnees_gps}', '_blank')">
                        <i class="fas fa-map-marker-alt"></i> Voir sur Google Maps
                    </button>
                </div>
            ` : ''}
        </div>
    `;
    
    modal.classList.add('active');
}

function filterPerimetres(searchText) {
    const cards = document.querySelectorAll('.perimetre-card');
    searchText = searchText.toLowerCase();
    
    cards.forEach(card => {
        const text = card.textContent.toLowerCase();
        card.style.display = text.includes(searchText) ? 'block' : 'none';
    });
}

// ================================
// Chargement des Parcelles
// ================================

function loadPerimetreFilters() {
    const filter = document.getElementById('filter-perimetre-parcelles');
    if (!filter) return;
    
    let html = '<option value="">Tous les périmètres</option>';
    mockData.perimetres.forEach(perimetre => {
        html += `<option value="${perimetre.id}">${perimetre.nom}</option>`;
    });
    filter.innerHTML = html;
}

function loadParcelles() {
    const tbody = document.getElementById('parcelles-tbody');
    if (!tbody) return;
    
    // Message pour connexion MySQL
    tbody.innerHTML = `
        <tr>
            <td colspan="7" style="text-align: center; padding: 3rem;">
                <i class="fas fa-database" style="font-size: 3rem; color: var(--text-light); margin-bottom: 1rem;"></i>
                <p style="color: var(--text-light); font-size: 1.1rem;">
                    Connexion à la base de données MySQL requise
                </p>
                <p style="color: var(--text-light); margin-top: 0.5rem;">
                    Veuillez configurer le backend (api.php ou Flask) pour afficher les données
                </p>
            </td>
        </tr>
    `;
}

// ================================
// Chargement des Ouvrages
// ================================

function loadOuvrages() {
    const tbody = document.getElementById('ouvrages-tbody');
    if (!tbody) return;
    
    // Message pour connexion MySQL
    tbody.innerHTML = `
        <tr>
            <td colspan="7" style="text-align: center; padding: 3rem;">
                <i class="fas fa-database" style="font-size: 3rem; color: var(--text-light); margin-bottom: 1rem;"></i>
                <p style="color: var(--text-light); font-size: 1.1rem;">
                    Connexion à la base de données MySQL requise
                </p>
                <p style="color: var(--text-light); margin-top: 0.5rem;">
                    Veuillez configurer le backend (api.php ou Flask) pour afficher les données
                </p>
            </td>
        </tr>
    `;
}

// ================================
// Statistiques et Graphiques
// ================================

function loadStatistics() {
    loadOverviewStats();
    setTimeout(() => {
        createRegionChart();
        createOuvragesChart();
        createExploitationChart();
        loadCulturesStats();
    }, 100);
}

function loadOverviewStats() {
    const container = document.getElementById('overview-stats');
    if (!container) return;
    
    const totalRegions = mockData.regions.length;
    const totalPerimetres = mockData.regions.reduce((sum, r) => sum + r.perimetres, 0);
    const totalParcelles = mockData.regions.reduce((sum, r) => sum + r.parcelles, 0);
    const totalOuvrages = mockData.regions.reduce((sum, r) => sum + r.ouvrages, 0);
    
    container.innerHTML = `
        <div class="overview-item">
            <i class="fas fa-map-marked-alt" style="font-size: 2rem; color: var(--primary-color); margin-bottom: 0.5rem;"></i>
            <span class="overview-number">${totalRegions}</span>
            <span class="overview-label">Régions</span>
        </div>
        <div class="overview-item">
            <i class="fas fa-seedling" style="font-size: 2rem; color: var(--success-color); margin-bottom: 0.5rem;"></i>
            <span class="overview-number">${totalPerimetres}</span>
            <span class="overview-label">Périmètres</span>
        </div>
        <div class="overview-item">
            <i class="fas fa-th" style="font-size: 2rem; color: var(--accent-color); margin-bottom: 0.5rem;"></i>
            <span class="overview-number">${formatNumber(totalParcelles)}</span>
            <span class="overview-label">Parcelles</span>
        </div>
        <div class="overview-item">
            <i class="fas fa-tools" style="font-size: 2rem; color: var(--warning-color); margin-bottom: 0.5rem;"></i>
            <span class="overview-number">${totalOuvrages}</span>
            <span class="overview-label">Ouvrages</span>
        </div>
    `;
}

function createRegionChart() {
    const canvas = document.getElementById('chart-regions');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    
    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: mockData.regions.map(r => r.nom),
            datasets: [{
                data: mockData.regions.map(r => r.parcelles),
                backgroundColor: [
                    '#27ae60',
                    '#3498db',
                    '#e74c3c',
                    '#f39c12',
                    '#9b59b6',
                    '#1abc9c'
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    position: 'bottom'
                },
                title: {
                    display: true,
                    text: 'Répartition des parcelles par région'
                }
            }
        }
    });
}

function createOuvragesChart() {
    const canvas = document.getElementById('chart-ouvrages');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Bon État', 'État Moyen', 'Médiocre', 'Hors Service'],
            datasets: [{
                data: [10, 4, 2, 0],
                backgroundColor: ['#27ae60', '#f39c12', '#e74c3c', '#95a5a6']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

function createExploitationChart() {
    const canvas = document.getElementById('chart-exploitation');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: mockData.regions.map(r => r.nom),
            datasets: [{
                label: 'Nombre de parcelles',
                data: mockData.regions.map(r => r.parcelles),
                backgroundColor: '#27ae60'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

function loadCulturesStats() {
    const container = document.getElementById('cultures-stats');
    if (!container) return;
    
    const cultures = [
        { nom: 'Palmier dattier', nombre: 450, icon: 'fa-tree' },
        { nom: 'Légumes', nombre: 320, icon: 'fa-carrot' },
        { nom: 'Céréales', nombre: 180, icon: 'fa-wheat-awn' },
        { nom: 'Fourrage', nombre: 120, icon: 'fa-leaf' }
    ];
    
    let html = '<div style="display: grid; gap: 1rem;">';
    cultures.forEach(culture => {
        html += `
            <div style="display: flex; align-items: center; justify-content: space-between; padding: 1rem; background: var(--bg-light); border-radius: var(--border-radius);">
                <div style="display: flex; align-items: center; gap: 1rem;">
                    <i class="fas ${culture.icon}" style="font-size: 1.5rem; color: var(--primary-color);"></i>
                    <span style="font-weight: 600;">${culture.nom}</span>
                </div>
                <span style="font-size: 1.2rem; font-weight: 700; color: var(--primary-color);">${culture.nombre}</span>
            </div>
        `;
    });
    html += '</div>';
    
    container.innerHTML = html;
}

// ================================
// Filtrage de Tableaux
// ================================

function filterTable(tableId, searchText) {
    const table = document.getElementById(tableId);
    if (!table) return;
    
    const tbody = table.querySelector('tbody');
    const rows = tbody.getElementsByTagName('tr');
    searchText = searchText.toLowerCase();
    
    for (let row of rows) {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchText) ? '' : 'none';
    }
}

// ================================
// Modals
// ================================

function openAddModal(type) {
    const modal = document.getElementById('modal');
    const title = document.getElementById('modal-title');
    const body = document.getElementById('modal-body');
    
    title.innerHTML = `<i class="fas fa-plus"></i> Ajouter un(e) ${type}`;
    body.innerHTML = generateForm(type);
    
    modal.classList.add('active');
}

function generateForm(type) {
    // Formulaires simplifiés - À développer selon les besoins
    return `
        <div style="text-align: center; padding: 2rem;">
            <i class="fas fa-database" style="font-size: 3rem; color: var(--text-light); margin-bottom: 1rem;"></i>
            <p style="color: var(--text-light); font-size: 1.1rem;">
                Fonctionnalité d'ajout requiert une connexion backend
            </p>
            <p style="color: var(--text-light); margin-top: 0.5rem;">
                Configurez api.php ou Flask pour activer cette fonctionnalité
            </p>
        </div>
    `;
}

function closeModal() {
    document.getElementById('modal').classList.remove('active');
}

function closeDetailModal() {
    document.getElementById('detail-modal').classList.remove('active');
}

function saveModalData() {
    showToast('Fonctionnalité à implémenter avec le backend', 'warning');
    closeModal();
}

// ================================
// Téléchargement de Fichiers
// ================================

function downloadFile(filename) {
    showToast(`Téléchargement de ${filename}...`, 'info');
    // Logique de téléchargement à implémenter
}

function viewSchema() {
    showToast('Ouverture du schéma de la base de données...', 'info');
    // Logique d'affichage à implémenter
}

// ================================
// Initialisation
// ================================

document.addEventListener('DOMContentLoaded', function() {
    // Charger les statistiques de l'accueil
    updateHomeStats();
    
    // Charger la section par défaut
    showSection('accueil');
    
    // Gérer le scroll pour la navbar
    window.addEventListener('scroll', function() {
        const navbar = document.querySelector('.navbar');
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });
    
    // Fermer les modals en cliquant en dehors
    document.getElementById('modal').addEventListener('click', function(e) {
        if (e.target === this) closeModal();
    });
    
    document.getElementById('detail-modal').addEventListener('click', function(e) {
        if (e.target === this) closeDetailModal();
    });
});

function updateHomeStats() {
    const totalRegions = mockData.regions.length;
    const totalPerimetres = mockData.regions.reduce((sum, r) => sum + r.perimetres, 0);
    const totalParcelles = mockData.regions.reduce((sum, r) => sum + r.parcelles, 0);
    const totalOuvrages = mockData.regions.reduce((sum, r) => sum + r.ouvrages, 0);
    
    const statRegions = document.getElementById('stat-regions');
    const statPerimetres = document.getElementById('stat-perimetres');
    const statParcelles = document.getElementById('stat-parcelles');
    const statOuvrages = document.getElementById('stat-ouvrages');
    
    if (statRegions) statRegions.textContent = totalRegions;
    if (statPerimetres) statPerimetres.textContent = totalPerimetres;
    if (statParcelles) statParcelles.textContent = formatNumber(totalParcelles);
    if (statOuvrages) statOuvrages.textContent = totalOuvrages;
}

// ================================
// Export pour utilisation globale
// ================================

window.showSection = showSection;
window.toggleMobileMenu = toggleMobileMenu;
window.showRegionDetails = showRegionDetails;
window.showPerimetreDetails = showPerimetreDetails;
window.filterByRegion = filterByRegion;
window.filterRegions = filterRegions;
window.filterPerimetres = filterPerimetres;
window.filterTable = filterTable;
window.loadPerimetres = loadPerimetres;
window.loadParcelles = loadParcelles;
window.loadOuvrages = loadOuvrages;
window.openAddModal = openAddModal;
window.closeModal = closeModal;
window.closeDetailModal = closeDetailModal;
window.saveModalData = saveModalData;
window.downloadFile = downloadFile;
window.viewSchema = viewSchema;
